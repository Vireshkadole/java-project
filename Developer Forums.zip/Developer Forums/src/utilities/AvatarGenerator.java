package utilities;

import gravatar.Gravatar;
import gravatar.GravatarDefaultImage;
import gravatar.GravatarRating;

public class AvatarGenerator {
	
	public AvatarGenerator() {
		
	}
	
	public String CreateAvatar(String Email,int Size) {
		 Gravatar gravatar = new Gravatar();
		 gravatar.setSize(Size);
		 gravatar.setRating(GravatarRating.GENERAL_AUDIENCES);
		 gravatar.setDefaultImage(GravatarDefaultImage.IDENTICON);
		 return  gravatar.getUrl(Email);
	}
	
}
