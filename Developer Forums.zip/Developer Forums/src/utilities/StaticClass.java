package utilities;

public class StaticClass {
	public static int ScreenWidth = 762;
	public static int ScreenHeight = 540;
	
	public static int TabPanelWidth = 717;
	public static int TabPanelHeight = 413;
	
}
