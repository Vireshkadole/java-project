package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.lang.reflect.Method;

public class QueryRequest {
	
	public static boolean requestLoginUser(String UserName,String Password) {
			boolean res = true;
			String url = "jdbc:postgresql://localhost:5432/devforums";
	        try {
		        Connection con = DriverManager.getConnection(url, "postgres", "pesu123");
	
		        try {
		        	PreparedStatement preparedStatement = 
		        			con.prepareStatement(Queries.SelectOneUser(UserName));
		        	ResultSet st = preparedStatement.executeQuery();
		        	
		        	int count = 0;
		        	while (st.next())
		        	{
		        		count++;
		        		//row by row
		        		String s = st.getString("Password");
		        		if(!Password.equals(s)) {
		        			res = false;
		        		}
		        		else {
		        			res = true;
		        			break;
		        		}
		        	}
		        	if(count == 0) {
		        		res = false;
		        	}
		        	
		        	preparedStatement.close();
		        	con.close();
		        	
		        } catch (SQLException ex) {
		            // TODO Auto-generated catch block
		            ex.printStackTrace();
		            res = false;
		        }
	
	
	    } catch (Exception exp) {
	        System.out.println(exp);
	        res = false;
	    }

		return res;
	}

	public static boolean requestRegisterUser(String UserName,String Email,String Password) {
		boolean res = true;
		String url = "jdbc:postgresql://localhost:5432/devforums";
        try {
	        Connection con = DriverManager.getConnection(url, "postgres", "pesu123");

	        try {
	        	PreparedStatement preparedStatement = 
	        			con.prepareStatement(Queries.SelectOneUser(UserName));
	        	ResultSet st = preparedStatement.executeQuery();
	        	
	        	int count = 0;
	        	while (st.next())
	        	{
	        		count++;
	        	}
	        	if(count > 0) {
	        		res = false;
	        	}
	        	
	        	if(res) {
	        		// Insert User

	        		PreparedStatement pst = con.prepareStatement(Queries.InsertNewUser(UserName,Email,Password,"")) ;
	        		//	pst.setLong(1, 1);
			        //pst.setString(1,  "god");
			        
			        
			        pst.executeUpdate();
			        pst.close();
			        con.close();
	        	}
	        	
	        	preparedStatement.close();
	        	con.close();
	        	
	        } catch (SQLException ex) {
	            // TODO Auto-generated catch block
	            ex.printStackTrace();
	            res = false;
	        }


    } catch (Exception exp) {
        System.out.println(exp);
        res = false;
    }
		return res;
	}
	
}

//		Select User
//String sql = "select * from usertable;";
//PreparedStatement preparedStatement = con.prepareStatement(sql);
//ResultSet st = preparedStatement.executeQuery();
//
//while (st.next())
//{
//	//row by row
//	String s = st.getString("Email");
//	System.out.println(s);
//}
//
//preparedStatement.close();
//con.close();
//

// Insert new User
////String sql = "delete from usertable where emp_name = ?;";
//String sql = Queries.InsertNewUser;
//PreparedStatement pst = con.prepareStatement(sql) ;
////    pst.setLong(1, 1);
////pst.setString(1,  "god");
//
//
//pst.executeUpdate();
//pst.close();
//con.close();

// remove User
//String sql = Queries.RemoveUser(2);
////String sql = Queries.InsertNewUser;
//PreparedStatement pst = con.prepareStatement(sql) ;
////    pst.setLong(1, 1);
////pst.setString(1,  "god");
//
//
//pst.executeUpdate();
//pst.close();
//con.close();



