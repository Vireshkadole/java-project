package DataBase;

public class Queries {
	// login queries
	public static String pl = "";
	
	// Check validUser
	public static String SelectOneUser(String Username) {
		return "SELECT * FROM UserTable WHERE username = '"+Username+"';";
	}
	
	// Add new user
	public static String InsertNewUser(String UserName,String Email,String Password,String Avatar) {
		return "INSERT INTO UserTable ( UserName, Email,Password,avatarurl)\r\n"
				+ "VALUES ('"+UserName+"',' "+Email+"','"+Password+"','"+Avatar+"');";
	}
	
	// remove user
	public static String RemoveUser(int userID) {
		return "delete from usertable where UserID = "+userID+";";
	}
	
	
	
	
	// .......
	
	
}
