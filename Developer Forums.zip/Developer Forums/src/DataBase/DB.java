package DataBase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
private static DB instance;
	
	public static DB getInstance() {
		if(instance == null) {
			instance = new DB();
		}
		return instance;
	}
	
	public boolean IsConnected = false;
	
	private DB() {
		 try (Connection conn = DriverManager.getConnection(
	                "jdbc:postgresql://127.0.0.1:5432/devforums", "postgres", "pesu123")) {

	            if (conn != null) {
	            	IsConnected = true;
	                System.out.println("Connected to the database!");
	            } else {
	                System.out.println("Failed to make connection!");
	            }
	        } catch (SQLException e) {
	        	System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	
	public String LoginUser( String UserName, String Password) {
		
		if(UserName == "" || Password == "") return "Invalid Inputs";
		if(QueryRequest.requestLoginUser(UserName,Password)) {
			return "";
		}
		return "Invalid Credentials!";
	}
	
	public String RegisterUser(String Username,String EmailID,String Password) {
		if(Username == "" || Password == "" || Password == "") return "Invalid Inputs";
		if(QueryRequest.requestRegisterUser(Username,EmailID,Password)) {
			return "";
		}
		return "Invalid Credentials! / User already exist!";
	}
	
}
