package Forums;

public class Models {
	
	public class User{
		public Boolean isAdmin;
		public String UserName;
		public String Email;
		public String Password;
		public String UserID;
		
		public User(String Username,String Email,String Password,String UserID,Boolean isadmin){
			this.UserName = Username;
			this.Email = Email;
			this.isAdmin = isadmin;
			this.Password = Password;
			this.UserID = UserID;
		}
		
	}
	
	
}
