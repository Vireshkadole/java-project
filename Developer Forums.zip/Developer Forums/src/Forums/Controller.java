package Forums;

import java.awt.EventQueue;

import DataBase.DB;

public class Controller {
	
	// Singleton
	private static Controller instance = null;
	
	public static Controller GetInstance() {
		if(instance == null) {
			instance  = new Controller();
		}
		return instance;
	}
	
	// properties & methods

	public view window ;
	public DB dataBase;
	
	private Controller() {
		// Run UI
		InitUI();
		
		//Connect To DB
		InitDB();

		
	}
	
	private void InitUI() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					window = new view();
					window.frame.setVisible(true);
					
					SetPanel();
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void InitDB() {
		dataBase = DB.getInstance();
	}
	
	private void SetPanel() {

		var loginPanel = window.SetPanel("Login");
		loginPanel.ShowPanel();
		
	}
	
}


