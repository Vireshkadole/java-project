package Forums;

import java.awt.EventQueue;

import javax.swing.JFrame;

import Panels.LoginPanel;
import Panels.RegisterPanel;
import Panels.panel;
import utilities.StaticClass;


public class view {

	public JFrame frame;

	public view() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SetWindow();	
	}
	
	private void SetWindow() {
		frame = new JFrame("Dev Forums (Team I9)");
		frame.setBounds(100, 100, StaticClass.ScreenWidth,StaticClass.ScreenHeight);
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public panel SetPanel(String panelName) {
		if(panelName == "") {
			return null;
		}
		
		switch(panelName) {
			case"Login":
				return new LoginPanel(frame);
			case "Register":
				return new RegisterPanel(frame);
			default:
				return null;
				
		}
		
	}

}
