package Panels;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Forums.Controller;
import utilities.StaticClass;


public class RegisterPanel extends JPanel implements panel {

	JFrame frame;
	private JTextField UsernameInput;
	private JTextField PasswordInput;
	private JTextField EmailInput;
	JLabel ErrorLabel;
	
	public RegisterPanel(JFrame frame) {
		this.frame = frame;
		
		this.setBounds(0,0,StaticClass.ScreenWidth,StaticClass.ScreenHeight);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Dev Forums");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(6, 27, 750, 45);
		add(lblNewLabel);
		
		JLabel RegisterLabel = new JLabel("Register");
		RegisterLabel.setHorizontalAlignment(SwingConstants.CENTER);
		RegisterLabel.setBounds(6, 84, 750, 23);
		add(RegisterLabel);
		
		JLabel UserNameLabel = new JLabel("User Name");
		UserNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		UserNameLabel.setHorizontalAlignment(SwingConstants.LEFT);
		UserNameLabel.setBounds(287, 155, 212, 23);
		add(UserNameLabel);
		
		UsernameInput = new JTextField();
		UsernameInput.setBounds(277, 176, 222, 35);
		add(UsernameInput);
		UsernameInput.setColumns(10);
		
		JLabel PasswordLabel = new JLabel("Password");
		PasswordLabel.setHorizontalAlignment(SwingConstants.LEFT);
		PasswordLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		PasswordLabel.setBounds(287, 224, 212, 23);
		add(PasswordLabel);
		
		PasswordInput = new JTextField();
		PasswordInput.setColumns(10);
		PasswordInput.setBounds(277, 245, 222, 35);
		add(PasswordInput);
		
		JLabel ToRegisterLabel = new JLabel("Already have an Account?");
		ToRegisterLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OnLoginClicked();
			}
		});
		ToRegisterLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		ToRegisterLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ToRegisterLabel.setBounds(6, 391, 750, 28);
		add(ToRegisterLabel);
		
		JButton LoginBtn = new JButton("Register");
		LoginBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ErrorLabel.setText("");
				OnRegisterClicked();
			}
		});
		LoginBtn.setBounds(277, 431, 222, 45);
		add(LoginBtn);
		
		JLabel EmailLabel = new JLabel("Email");
		EmailLabel.setHorizontalAlignment(SwingConstants.LEFT);
		EmailLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		EmailLabel.setBounds(287, 297, 212, 23);
		add(EmailLabel);
		
		EmailInput = new JTextField();
		EmailInput.setColumns(10);
		EmailInput.setBounds(277, 318, 222, 35);
		add(EmailInput);
		
		ErrorLabel = new JLabel("");
		ErrorLabel.setForeground(Color.RED);
		ErrorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ErrorLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		ErrorLabel.setBounds(6, 361, 750, 28);
		add(ErrorLabel);
		
		HidePanel();
		
	}
	
	@Override
	public void ShowPanel() {
		frame.getContentPane().add(this);
		this.setVisible(true);
	}

	@Override
	public void HidePanel() {
		frame.remove(this);
		this.setVisible(false);
	}

	
	// On click Events
	
	private void OnLoginClicked() {
		HidePanel();
		
		var controller = Controller.GetInstance();
		var register = controller.window.SetPanel("Login");
		register.ShowPanel();
	}
	
	private void OnRegisterClicked() {
		if(CheckInputs()) {
			var error = CreateUser(UsernameInput.getText(),PasswordInput.getText(),EmailInput.getText());
			if(error.equals("")){
				// Register user
				ErrorLabel.setText("");
				System.out.println("Auth granted! Navigating to Login.");
				OnLoginClicked();
			}
			else {
				// Display Error
				ErrorLabel.setText(error);
			}
		}
	}
	
	// logic
	
	private boolean CheckInputs() {
		if(UsernameInput.getText().equals("") || PasswordInput.getText().equals("")) {
			ErrorLabel.setText("Non Empty Inputs");
			return false;
		}
		if(!CheckEmail() ) {
			ErrorLabel.setText("Invalid Email");
			return false;
		}
		return true;
	}
	
	private String CreateUser(String UserName,String Password,String Email) {
		return Controller.GetInstance().dataBase.RegisterUser(UserName,Email,Password);
	}
	
	private boolean CheckEmail() {
		String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
		
        Pattern pat = Pattern.compile(emailRegex);

        return pat.matcher(EmailInput.getText()).matches();
		
	}
}
