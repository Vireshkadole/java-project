package Panels;

public interface panel {
	public void ShowPanel();
	public void HidePanel();
}
