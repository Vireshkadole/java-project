package Panels;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import Forums.Controller;
import utilities.AvatarGenerator;
import utilities.StaticClass;

public class LoginPanel extends JPanel implements panel {


	JFrame frame;
	private JTextField UsernameInput;
	private JTextField PasswordInput;
	JLabel ErrorLabel;
	
	public LoginPanel(JFrame frame) {
		
		this.frame = frame;
		ErrorLabel = new JLabel("");
		
		this.setBounds(0,0,StaticClass.ScreenWidth,StaticClass.ScreenHeight);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Dev Forums");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(6, 27, 750, 45);
		add(lblNewLabel);
		
		JLabel LofinLabel = new JLabel("Login");
		LofinLabel.setHorizontalAlignment(SwingConstants.CENTER);
		LofinLabel.setBounds(6, 84, 750, 23);
		add(LofinLabel);
		
		JLabel UserNameLabel = new JLabel("User Name");
		UserNameLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		UserNameLabel.setHorizontalAlignment(SwingConstants.LEFT);
		UserNameLabel.setBounds(287, 155, 212, 23);
		add(UserNameLabel);
		
		UsernameInput = new JTextField();
		UsernameInput.setBounds(277, 176, 222, 35);
		add(UsernameInput);
		UsernameInput.setColumns(10);
		
		JLabel PasswordLabel = new JLabel("Password");
		PasswordLabel.setHorizontalAlignment(SwingConstants.LEFT);
		PasswordLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 15));
		PasswordLabel.setBounds(287, 224, 212, 23);
		add(PasswordLabel);
		
		PasswordInput = new JTextField();
		PasswordInput.setColumns(10);
		PasswordInput.setBounds(277, 245, 222, 35);
		add(PasswordInput);
		
		JLabel ToRegisterLabel = new JLabel("Create New Account?");
		ToRegisterLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				OnCreateAccountClicked();
			}
		});
		ToRegisterLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		ToRegisterLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ToRegisterLabel.setBounds(6, 328, 750, 28);
		add(ToRegisterLabel);
		
		JButton LoginBtn = new JButton("Login");
		LoginBtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ErrorLabel.setText("");
				OnLoginClicked();
			}
		});
		LoginBtn.setBounds(277, 368, 222, 45);
		add(LoginBtn);
		
		
		ErrorLabel.setForeground(Color.RED);
		ErrorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ErrorLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
		ErrorLabel.setBounds(6, 288, 750, 28);
		add(ErrorLabel);
		
//		JLabel SampleImage = new JLabel("");
//		SampleImage.setBounds(48, 135, 80, 80);
//		add(SampleImage);
//		
//		Image image = null;
//        try {
//        	AvatarGenerator gen = new AvatarGenerator();
//        	var avaraturl = gen.CreateAvatar("Player@gmail.com",80);
//    		System.out.println (avaraturl);
//    		
//            URL url = new URL(avaraturl);
//            image = ImageIO.read(url);
//        } catch (IOException e) {
//        	e.printStackTrace();
//        }
//        
//        SampleImage.setIcon(new ImageIcon(image));
		
		HidePanel();
	}

	@Override
	public void ShowPanel() {
		frame.getContentPane().add(this);
		this.setVisible(true);
	}

	@Override
	public void HidePanel() {
		frame.remove(this);
		this.setVisible(false);
	}
	
	// On click Events
	
	private void OnCreateAccountClicked() {
		HidePanel();
		
		var controller = Controller.GetInstance();
		var register = controller.window.SetPanel("Register");
		register.ShowPanel();
	}
	
	private void OnLoginClicked() {
		if(CheckInputs()) {
			var error = CheckForValidUser(UsernameInput.getText(),PasswordInput.getText());
			if(error.equals("")){
				// Auth user
				ErrorLabel.setText("");
				System.out.println("Auth granted!");
			}
			else {
				// Display Error
				ErrorLabel.setText(error);
			}
		}
	}
	
	// logic
	
	private boolean CheckInputs() {
		if(UsernameInput.getText().equals("") || PasswordInput.getText().equals("")) {
			ErrorLabel.setText("Non Empty Inputs");
			return false;
		}
		return true;
	}
	
	private String CheckForValidUser(String UserName,String Password) {
		return Controller.GetInstance().dataBase.LoginUser(UserName,Password);
	}
}
