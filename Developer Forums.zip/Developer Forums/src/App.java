import java.awt.EventQueue;

import Forums.Controller;
import utilities.AvatarGenerator;

public class App {

	public static void main(String[] args) {
		// Hello
		System.out.println("Hello Developer Forums");
		
		// init controller
		Controller controller = Controller.GetInstance();
		
	}

}
